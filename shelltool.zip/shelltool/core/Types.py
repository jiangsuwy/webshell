# -*- encoding: utf-8 -*-
"""
@File    :   Types.py    
@Modify Time          @Author      @Version    
------------        -----------    --------    
2021/3/8 23:00      flandre2333      1.0         

@Description
-----------
   None
"""
from enum import Enum


class LanguageType(Enum):
    PHP = 1
    JAVA = 2
    ASP = 3
    ASPX = 4
